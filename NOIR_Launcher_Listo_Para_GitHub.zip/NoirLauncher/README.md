# NOIR Launcher

Launcher Android nativo en Kotlin con interfaz minimalista negro AMOLED, preparado como proyecto base para Motorola Signature.

## Funciones incluidas en esta revisión
- Actividad HOME seleccionable como launcher predeterminado.
- Reloj digital de 12 horas con AM/PM y fecha en español.
- Cajón de aplicaciones con buscador y orden alfabético.
- Accesos rápidos a Teléfono, WhatsApp, Cámara y Chrome (se localizan por el nombre visible instalado en el teléfono).
- Deslizar hacia arriba: cajón de aplicaciones.
- Deslizar hacia abajo: panel de notificaciones mediante el servicio de accesibilidad.
- Doble toque: bloquear pantalla mediante el servicio de accesibilidad.
- Mantener pulsada un área vacía: menú para añadir widgets, cambiar fondo e información de gestos.
- Selector y host inicial de widgets Android.
- Interfaz negra AMOLED y controles de alto contraste.
- Sin publicidad ni permisos de red añadidos por el proyecto.

## Importante sobre los gestos
Android exige que el usuario habilite manualmente el servicio **NOIR Launcher Gestos** en Ajustes > Accesibilidad. Sin esa autorización, Android no permite que una app normal despliegue el panel de notificaciones ni bloquee la pantalla mediante acciones globales. El launcher mostrará un aviso y abrirá los ajustes de accesibilidad.

## Requisitos de compilación
- Android Studio Ladybug o posterior.
- JDK 17.
- Android SDK 35.
- Android Gradle Plugin 8.7.3 / Kotlin 2.0.21.

## Compilar APK
1. Descomprime el ZIP y abre la carpeta `NoirLauncher` en Android Studio.
2. Espera la sincronización de Gradle.
3. Selecciona Build > Build APK(s).
4. El APK de depuración se genera en `app/build/outputs/apk/debug/app-debug.apk`.
5. Instálalo en el Motorola Signature y selecciónalo como aplicación de inicio predeterminada.

## Estado
Esta es una revisión del código fuente. No se incluye un APK compilado ni se afirma que esté verificado en hardware: en el entorno actual no están disponibles Gradle ni Android SDK para ejecutar la compilación. Es necesario compilar y probar en Android Studio, especialmente el comportamiento del servicio de accesibilidad, widgets y lanzamiento de las aplicaciones según las versiones instaladas.
