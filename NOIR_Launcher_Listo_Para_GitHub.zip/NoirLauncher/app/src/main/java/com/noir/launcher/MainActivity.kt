package com.noir.launcher

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private val black = Color.BLACK
    private val white = Color.WHITE
    private val muted = Color.rgb(150, 150, 150)
    private lateinit var root: LinearLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var content: LinearLayout
    private lateinit var appHost: AppWidgetHost
    private lateinit var widgetManager: AppWidgetManager
    private var drawerOpen = false
    private var downX = 0f
    private var downY = 0f
    private var lastTap = 0L
    private var longPressTriggered = false
    private val longPressAction = Runnable { showCustomizationMenu(); longPressTriggered = true }
    private val handler = Handler(Looper.getMainLooper())
    private val clockTick = object : Runnable {
        override fun run() {
            if (::clock.isInitialized) {
                clock.text = SimpleDateFormat("h:mm a", Locale("es", "CR")).format(Date()).uppercase(Locale("es", "CR"))
                date.text = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es", "CR")).format(Date())
                    .replaceFirstChar { it.uppercase(Locale("es", "CR")) }
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = black
        window.navigationBarColor = black
        window.decorView.systemUiVisibility = 0
        appHost = AppWidgetHost(this, 4200)
        widgetManager = AppWidgetManager.getInstance(this)
        appHost.startListening()
        showHome()
        handler.post(clockTick)
    }

    private fun showHome() {
        drawerOpen = false
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(black)
            setPadding(dp(24), dp(30), dp(24), dp(18))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(0, dp(30), 0, dp(22))
        }
        clock = TextView(this).apply {
            text = "00:00"
            textSize = 62f
            setTextColor(white)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
            letterSpacing = .02f
        }
        date = TextView(this).apply {
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
            letterSpacing = .08f
        }
        header.addView(clock)
        header.addView(date, LinearLayout.LayoutParams(-1, dp(28)))
        root.addView(header)

        val label = TextView(this).apply {
            text = "ESPACIO PERSONAL"
            textSize = 10f
            setTextColor(muted)
            letterSpacing = .18f
            setPadding(2, dp(12), 0, dp(10))
        }
        root.addView(label)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
        }
        val widgetHint = TextView(this).apply {
            text = "Mantén este espacio limpio o añade tus widgets favoritos."
            textSize = 13f
            setTextColor(Color.rgb(95,95,95))
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(28), dp(18), dp(28))
            background = rounded(Color.rgb(12,12,12), 18)
        }
        content.addView(widgetHint, LinearLayout.LayoutParams(-1, dp(112)))
        val addWidget = textButton("+  AÑADIR WIDGET")
        addWidget.setOnClickListener { startWidgetPicker() }
        content.addView(addWidget, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
        }
        listOf("Teléfono", "WhatsApp", "Cámara", "Chrome").forEach { name ->
            val item = TextView(this).apply {
                text = when (name) { "Teléfono" -> "⌕\nTeléfono"; "WhatsApp" -> "◌\nWhatsApp"; "Cámara" -> "◎\nCámara"; else -> "⌘\nChrome" }
                textSize = 11f
                setTextColor(white)
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(13), dp(10), dp(13))
                background = rounded(Color.rgb(18,18,18), 24)
                setOnClickListener {
                    launchByLabel(name)
                }
            }
            dock.addView(item, LinearLayout.LayoutParams(0, dp(60), 1f).apply {
                leftMargin = dp(4); rightMargin = dp(4)
            })
        }
        root.addView(dock)
        root.setOnTouchListener { _, event -> handleGesture(event) }
        setContentView(root)
    }

    private fun showDrawer() {
        drawerOpen = true
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(black)
            setPadding(dp(20), dp(32), dp(20), dp(12))
        }
        val title = TextView(this).apply {
            text = "APLICACIONES"
            textSize = 12f
            letterSpacing = .18f
            setTextColor(muted)
            setPadding(0, 0, 0, dp(18))
        }
        page.addView(title)
        val search = EditText(this).apply {
            hint = "Buscar aplicaciones"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            setSingleLine(true)
            background = rounded(Color.rgb(18,18,18), 20)
            setPadding(dp(16), 0, dp(16), 0)
        }
        page.addView(search, LinearLayout.LayoutParams(-1, dp(50)))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(14) })
        val apps = loadApps()
        fun populate(filter: String) {
            list.removeAllViews()
            apps.filter { it.loadLabel(packageManager).toString().contains(filter, true) }
                .forEach { info ->
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(dp(8), dp(9), dp(8), dp(9))
                    }
                    val icon = ImageView(this).apply {
                        setImageDrawable(info.loadIcon(packageManager))
                        scaleType = ImageView.ScaleType.FIT_CENTER
                    }
                    row.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
                    val name = TextView(this).apply {
                        text = info.loadLabel(packageManager)
                        textSize = 15f
                        setTextColor(white)
                        setPadding(dp(16), 0, 0, 0)
                    }
                    row.addView(name, LinearLayout.LayoutParams(0, dp(60), 1f))
                    row.setOnClickListener {
                        packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)?.let(::startActivity)
                    }
                    list.addView(row)
                }
        }
        populate("")
        search.addTextChangedListener(SimpleWatcher { populate(it) })
        page.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) { downX=e.x; downY=e.y }
            if (e.action == MotionEvent.ACTION_UP && e.y - downY > dp(80)) { showHome(); true } else false
        }
        setContentView(page)
    }

    private fun loadApps() = packageManager.queryIntentActivities(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
    ).sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }

    private fun launchByLabel(label: String) {
        val match = loadApps().firstOrNull { it.loadLabel(packageManager).toString().contains(label, true) }
        match?.let { packageManager.getLaunchIntentForPackage(it.activityInfo.packageName)?.let(::startActivity) }
            ?: startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
    }

    private fun startWidgetPicker() {
        val id = appHost.allocateAppWidgetId()
        val pick = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        @Suppress("DEPRECATION")
        startActivityForResult(pick, 77)
    }

    @Deprecated("Legacy activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                val id = data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
                val info = widgetManager.getAppWidgetInfo(id)
                if (info != null) {
                    val hostView: AppWidgetHostView = appHost.createView(this, id, info)
                    hostView.setAppWidget(id, info)
                    content.removeAllViews()
                    content.addView(hostView, LinearLayout.LayoutParams(-1, dp(180)))
                }
            }
        }
    }

    private fun handleGesture(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { downX=e.x; downY=e.y; longPressTriggered=false; handler.postDelayed(longPressAction, 550); return true }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressAction)
                if (longPressTriggered) return true
                val dx=e.x-downX; val dy=e.y-downY
                if (abs(dy) > dp(70) && abs(dy) > abs(dx)) {
                    if (dy < 0) showDrawer() else showNotifications()
                    return true
                }
                val now = System.currentTimeMillis()
                if (now-lastTap < 300) {
                    // El bloqueo de pantalla se realiza mediante el servicio de accesibilidad opcional.
                    lockScreen()
                    lastTap = 0
                } else lastTap = now
                return true
            }
        }
        return true
    }

    private fun showNotifications() {
        if (!NoirAccessibilityService.runGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)) {
            android.widget.Toast.makeText(this, "Activa el servicio de accesibilidad de NOIR para usar este gesto", Toast.LENGTH_LONG).show()
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun lockScreen() {
        if (!NoirAccessibilityService.runGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)) {
            android.widget.Toast.makeText(this, "Activa el servicio de accesibilidad de NOIR para bloquear con doble toque", Toast.LENGTH_LONG).show()
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun showCustomizationMenu() {
        val options = arrayOf("Añadir widget", "Cambiar fondo de pantalla", "Información de gestos")
        android.app.AlertDialog.Builder(this)
            .setTitle("Personalizar NOIR")
            .setItems(options) { _, which -> when (which) {
                0 -> startWidgetPicker()
                1 -> startActivity(Intent(Intent.ACTION_SET_WALLPAPER))
                2 -> android.app.AlertDialog.Builder(this).setMessage("Desliza hacia arriba para abrir aplicaciones. Desliza hacia abajo para notificaciones. Doble toque para bloquear. Los dos últimos requieren activar NOIR Launcher Gestos en Accesibilidad.").setPositiveButton("Aceptar", null).show()
            } }.show()
    }

    private fun textButton(label: String) = TextView(this).apply {
        text = label; textSize = 11f; gravity = Gravity.CENTER
        setTextColor(white); letterSpacing = .12f
        background = rounded(Color.rgb(15,15,15), 16)
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), Color.rgb(32,32,32))
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(clockTick)
        appHost.stopListening()
        super.onDestroy()
    }
}
